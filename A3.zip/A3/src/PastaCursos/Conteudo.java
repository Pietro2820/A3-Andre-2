package PastaCursos;

import java.util.ArrayList;

public class Conteudo {
    private String nome;
    private ArrayList<String> explicacao;

    public Conteudo(String nome, ArrayList<String> explicacao) {
        this.nome = nome;
        this.explicacao = explicacao;
    }

    // Construtor com nome e explicações vazias
    public Conteudo(String nome) {
        this.nome = nome;
        this.explicacao = new ArrayList<String>();
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public ArrayList<String> getExplicacao() {
        return explicacao;
    }

    public void setExplicacao(ArrayList<String> explicacao) {
        this.explicacao = explicacao;
    }

    // Método auxiliar para adicionar explicações
    public void adicionarExplicacao(String explicacao) {
        this.explicacao.add(explicacao);
    }
}
